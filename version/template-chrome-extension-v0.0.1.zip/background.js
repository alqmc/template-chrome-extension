(function(e){typeof define=="function"&&define.amd?define(e):e()})(function(){"use strict";console.log("template-chrome-extension")});
